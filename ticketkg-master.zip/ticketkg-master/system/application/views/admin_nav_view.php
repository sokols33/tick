<br />
<ul class="admin">
<li>
<a href="<?=base_url();?>adimin">Главная</a>
</li>
<li>
<a href="<?=base_url();?>adimin/email">Рассылка</a>
</li>
<li>
<a href="<?=base_url();?>adimin/money_gen">Генерация времени</a>
</li>
<li>
<a href="<?=base_url();?>adimin/add_rozyg">Добавить розыгрыш</a>
</li>
<li>
<a href="<?=base_url();?>adimin/readExcel">Считать эксель</a>
</li>
<li>
<a href="<?=base_url();?>auth">Пользователи</a>
</li>
</ul><br />