<div id="container">
<div class="clear mymarg"></div>
<div class="window_simp">
<h1><?php echo lang('activation_heading');?></h1>
<p><?php echo lang('activation_subheading');?></p>
<div id="infoMessage"><?php echo $message;?></div>

<br />
<br /><br /><br /><br /><br /><br /><br />


</div>

<div class="clear"></div>

</div>