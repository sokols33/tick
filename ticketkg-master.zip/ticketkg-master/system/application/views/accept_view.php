<div id="container">
<div id="success">
<h2><span class="green_text">Номер вашего заказа:</span> <?=$this->session->flashdata('message');?></h2><br />
<h2><span class="green_text">Код доступа к вашему заказу:</span> <?=$this->session->flashdata('pincode');?></h2><br /><br />
<br />
<p class="clear">Ваш заказ принят в обработку. Оператор свяжется с Вами в течение 30 минут для подтверждения заказа. Спасибо!</p>
<br/>

<div id="alert">
<div id="busket_in">
<p><strong class="alert">Внимание!</strong></p>
<p>Необходимо запомнить номер заказа и код доступа к нему.</p>
</div>
</div>


<div style="height:15px; width:1000px; margin:0 auto;" class="clear"></div>


</div>
</div>