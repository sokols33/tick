	<div class="row">
		<div class="col-md-12">
		</div>
	</div>
	<div class="row">
		<div class="col-md-12">
			<h1></h1>
		</div>
	</div>
	<div id="content" class="row">
		<div class="col-md-12">
			<div id="featured" class="col-md-12">
				<?php if(isset($info)){echo $info."<br><br><a href=".$link.">Вернуться</a>";} ?>
			</div>
		</div>
	</div>

	</div>