
	<h1><?=$main_info['title'];?> <span style="color: #137171; border-bottom: 1px dashed #137171;"></span></h1>
    <p>
    <?=$main_info['main_text'];?>
    </p>
</div>