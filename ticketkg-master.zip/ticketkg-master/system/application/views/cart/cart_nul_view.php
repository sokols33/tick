<div id="content" class="row">
		<div id="featured" class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
			<h2 class="center">Ваша корзина пуста</h2>
		</div>
</div>
</div>
	