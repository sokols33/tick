<!-- NAVIGATION -->
<div id="navigation">
<div id="navigation_in">
<div id="catalogue_block">
<div id="catalog_drop"  class="droplist">
<div id="rightnavhead">
<p class="strong"><img src="/img/list.png" width="8"/>&nbsp;&nbsp;КАТАЛОГ ТОВАРОВ</p>
</div>
</div>
</div>
<div id="nav_other">
<ul>
<a href=""><li>Акция</li></a>
<a href=""><li>Новинки</li></a>
<a href=""><li>Партнеры</li></a>
<a href=""><li>Новости</li></a>
</ul>
</div>
</div>
</div>