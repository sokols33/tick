<!-- CONTAINER -->
<div id="stripe">
<div id="container" class="stripe_in">
<h1>Ваша корзина</h1>
</div>
</div>
<div id="container">
<div style="height: 300px; width: 800px;">
<br />
<h2 class="info radius">К сожалению ваша корзина пуста</h2>
</div>
</div>
</div>
<div class="clear"></div><br /><br />
