<?php
$lang['ut_test_name']       = 'Имя теста';
$lang['ut_test_datatype']   = 'Тестируемый тип данных ';
$lang['ut_res_datatype']    = 'Ожидаемый тип данных';
$lang['ut_result']          = 'Результат';
$lang['ut_undefined']       = 'Имя теста не задано';
$lang['ut_file']            = 'Имя файла';
$lang['ut_line']            = 'Номер строки';
$lang['ut_passed']          = 'Пройден';
$lang['ut_failed']          = 'Не пройден';
// не уверен, что стоит вообще переводить типы данных
$lang['ut_boolean']         = 'Boolean';
$lang['ut_integer']         = 'Integer';
$lang['ut_float']           = 'Float';
$lang['ut_double']          = 'Float'; // can be the same as float
$lang['ut_string']          = 'String';
$lang['ut_array']           = 'Array';
$lang['ut_object']          = 'Object';
$lang['ut_resource']        = 'Resource';
$lang['ut_null']            = 'Null';